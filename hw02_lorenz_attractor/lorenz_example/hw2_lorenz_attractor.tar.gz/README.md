HW2 Lorenz Attractor
--------------------
Lucas Laughlin
----------------------------------------------------------
Goes from cyan to white with each additional iteration of the Eular method.

----------------------------------------------------------
Key Bindings
----------------------------------------------------------

left & right arrow keys - rotate view around the x axis
up & down arrow keys - rotate view around the y axis

q - increment sigma
a - decrement sigma

w - increment beta by 0.5
s - decrement beta by 0.5

e - increment rho 
d - decrement rho

0 - resets view
r - resets sigma, beta, rho

x - toggles axes
